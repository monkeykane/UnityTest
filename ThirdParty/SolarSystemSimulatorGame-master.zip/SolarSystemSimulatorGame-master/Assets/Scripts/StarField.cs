﻿using UnityEngine;
using System.Collections;

public class StarField : MonoBehaviour
{	
	void LateUpdate ()
	{
		transform.rotation = Quaternion.identity;
	}
}

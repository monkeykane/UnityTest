# UnityEditorListView
Unity 编辑器列表控件

# 功能
* 点击选中
* 键盘移动
* 多行多列
* 拖曳排序
* 接受外部文件拖放
* 支持自定义数据拖曳

# 截图
![](https://github.com/akof1314/UnityEditorListView/raw/master/Screenshots/default.png)

# 说明
代码提取自 Unity 编辑器反编译出来的代码
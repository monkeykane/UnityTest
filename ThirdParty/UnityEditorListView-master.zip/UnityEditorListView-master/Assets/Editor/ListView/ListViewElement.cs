using System;
using UnityEngine;
namespace WH.Editor
{
	public struct ListViewElement
	{
		public int row;
		public int column;
		public Rect position;
	}
}
